import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { RouterModule } from '@angular/router';
import { DoctorService } from '../doctor.service';

@Component({
  selector: 'app-delete-doctor',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule, MatTableModule, MatIconModule, MatButtonModule, MatDialogModule, MatFormFieldModule,
      MatInputModule,RouterModule],
  templateUrl: './delete-doctor.component.html',
  styleUrl: './delete-doctor.component.css'
})
export class DeleteDoctorComponent {
  constructor(private dialogRef: MatDialogRef<DeleteDoctorComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private doctorService: DoctorService
  ) {}

  onCancel(): void {
    this.dialogRef.close(); // Close the dialog without doing anything
  }
  onDelete(): void {
    if (!this.data.doctor || !this.data.doctor.id) {
      alert('Invalid doctor data. Please try again.');
      this.dialogRef.close('error');
      return;
    }
  
    this.doctorService.deleteDoctor(this.data.doctor.id).subscribe(
      () => {
        console.log('Doctor deleted successfully');
        this.dialogRef.close('deleted'); // Notify parent of success
      },
      (error) => {
        console.error('Error deleting doctor:', error);
        if (error.status === 404) {
          alert('Doctor not found. It may have already been deleted.');
        } else {
          alert('Error deleting doctor. Please try again.');
        }
        this.dialogRef.close('error'); // Notify parent of error
      }
    );
  }
}  