import { Component, OnInit } from '@angular/core';
import { PatientDashboardService } from '../patient-dashboard.service';
import { RouterLink, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-patient-dashboard',
  standalone: true,
  imports: [FormsModule,ReactiveFormsModule, CommonModule, RouterModule, RouterLink],
  templateUrl: './patient-dashboard.component.html',
  styleUrl: './patient-dashboard.component.css'
})
export class PatientDashboardComponent implements OnInit {
  doctors: any[] = [];
  selectedDoctor: any = null;
  appointmentDate: string = '';
  appointmentTime: string = '';
  bookingMessage: string = '';
  errorMessage: string = '';

  minTime: string = '10:00'; // Default minimum time (10 AM)
  maxTime: string = '18:00'; // Default maximum time (6 PM)

  constructor(private patientdashboardService: PatientDashboardService) {}

  ngOnInit(): void {
    this.loadDoctors();
  }

  loadDoctors(): void {
    this.patientdashboardService.getAllDoctors().subscribe(
      (data: any[]) => {
        this.doctors = data;
      },
      (error: any[]) => {
        console.error('Error fetching doctors:', error);
      }
    );
  }

  onDoctorChange(): void {
    if (this.selectedDoctor) {
      this.appointmentDate = '';
      this.appointmentTime = '';
      this.bookingMessage = '';
      this.errorMessage = '';
    }
  }

  validateAppointment(): boolean {
    if (!this.appointmentDate || !this.appointmentTime) {
      this.errorMessage = 'Please select a valid date and time.';
      return false;
    }

    const appointmentDay = new Date(this.appointmentDate).getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    if (appointmentDay === 0 || appointmentDay === 6) {
      this.errorMessage = 'Invalid appointment. Please select a weekday (Monday to Friday).';
      return false;
    }

    const appointmentMinutes = this.convertTimeToMinutes(this.appointmentTime);
    const minMinutes = this.convertTimeToMinutes(this.minTime);
    const maxMinutes = this.convertTimeToMinutes(this.maxTime);

    if (appointmentMinutes < minMinutes || appointmentMinutes > maxMinutes) {
      this.errorMessage = `Invalid time. Please select a time between ${this.minTime} and ${this.maxTime}.`;
      return false;
    }

    return true;
  }

  convertTimeToMinutes(time: string): number {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }

  bookAppointment(): void {
    if (this.validateAppointment()) {
      this.bookingMessage = `Appointment booked with  ${this.selectedDoctor?.name || 'Default'} on ${this.appointmentDate} at ${this.appointmentTime}.`;
      this.errorMessage = '';
    }
  }
}
