import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AdminLoginService } from '../admin-login.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { MatSnackBar  } from '@angular/material/snack-bar';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent {
  loginForm: FormGroup;

  private readonly validUsername = 'admin';
  private readonly validPassword = 'admin@123';

  constructor(private fb: FormBuilder, private router: Router) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onLogin() {
    const { username, password } = this.loginForm.value;

    if (username === this.validUsername && password === this.validPassword) {
      alert('Signed in successfully!');
      this.router.navigate(['/admin-dashboard']);
    } else {
      this.showErrorAlert();
    }
  }

  private showErrorAlert() {
    alert('Invalid credentials! Please try again.');
  }

  get f() {
    return this.loginForm.controls;
  }
}
