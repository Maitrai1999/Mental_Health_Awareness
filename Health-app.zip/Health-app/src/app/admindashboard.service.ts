import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { LoginService } from './login.service';
import { AdminLoginService } from './admin-login.service';

@Injectable({
  providedIn: 'root'
})
export class AdminDashboardComponent implements CanActivate {
  constructor(private adminloginService: AdminLoginService, private router: Router) {}

  canActivate(): boolean {
    if (this.adminloginService.isAdminLoggedIn()) {
      return true;
    }
    // Redirect to admin login if not authenticated
    this.router.navigate(['/admin']);
    return false;
  }
}
