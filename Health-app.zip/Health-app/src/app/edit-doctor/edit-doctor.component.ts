import { ChangeDetectorRef, Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { DoctorService } from '../doctor.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { RouterLink, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-edit-doctor',
  standalone: true,
  imports: [ CommonModule,ReactiveFormsModule,FormsModule,ReactiveFormsModule, RouterModule, RouterLink ],
  templateUrl: './edit-doctor.component.html',
  styleUrl: './edit-doctor.component.css'
})
export class EditDoctorComponent {
  doctorForm: FormGroup;
  isUpdateSuccessful: boolean | null = null; // Flag to track update status
  updateMessage: string = ''; // Message to display update status
  
  @Output() doctorUpdated = new EventEmitter<void>(); // Notify parent to refresh the list

  constructor(
    private fb: FormBuilder,
    private doctorService: DoctorService,
    public dialogRef: MatDialogRef<EditDoctorComponent>,
    @Inject(MAT_DIALOG_DATA) public doctorData: any,
    private cdr: ChangeDetectorRef
  ) {
    // Initialize the form with doctor data
    this.doctorForm = this.fb.group({
      id: [doctorData?.id, Validators.required],
      name: [doctorData?.name, Validators.required],
      email: [doctorData?.email, [Validators.required, Validators.email]],
      contactNumber: [doctorData?.contactNumber, Validators.required],
      specialization: [doctorData?.specialization, Validators.required],
      availability: [doctorData?.availability, Validators.required]
    });
  }

  // Method to handle form submission
  onSubmit(): void {
    if (this.doctorForm.valid) {
      const updatedDoctor = this.doctorForm.value;
      const doctorId = this.doctorData.id;

      this.doctorService.updateDoctor(doctorId, updatedDoctor).subscribe(
        (response) => {
          console.log('Doctor updated successfully:', response);
          this.isUpdateSuccessful = true;
          this.updateMessage = 'Doctor updated successfully!';
          this.cdr.detectChanges(); // Manually trigger change detection
          this.doctorUpdated.emit(); // Notify parent to refresh the list
          setTimeout(() => this.dialogRef.close(response), 3000); // Close dialog after 3 seconds
        },
        (error) => {
          console.error('Error updating doctor:', error);
          this.isUpdateSuccessful = false;
          this.updateMessage = 'Error updating doctor. Please try again.';
          this.cdr.detectChanges(); // Manually trigger change detection
        }
      );
    }
  }

  // Method to handle cancel action
  onCancel(): void {
    this.dialogRef.close(false); // Close dialog without saving
  }
}