import { CommonModule } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DoctorComponent } from '../doctor/doctor.component';
import { MatTableModule } from '@angular/material/table'; 
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { DoctorService } from '../doctor.service';
import { EditDoctorComponent } from '../edit-doctor/edit-doctor.component';
import { ChangeDetectorRef } from '@angular/core';
import { DeleteDoctorComponent } from '../delete-doctor/delete-doctor.component';


@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule, MatTableModule, MatIconModule, MatButtonModule, MatDialogModule, MatFormFieldModule,
    MatInputModule,RouterModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit {
  doctors: any[] = [];
  displayedColumns: string[] = [
    'id', 'name', 'email', 'specialization', 'contactNumber', 'availability', 'actions'
  ];
  @Output() doctorUpdated = new EventEmitter<void>();

  constructor(
    private doctorService: DoctorService,
    public dialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadDoctors();
  }

  loadDoctors(): void {
    this.doctorService.getAllDoctors().subscribe(
      (doctors) => {
        console.log('Doctors loaded successfully:', doctors);
        this.doctors = doctors;
        this.cdr.detectChanges(); // Ensure the UI updates
      },
      (error) => {
        console.error('Error loading doctors:', error);
        alert('Error loading doctors. Please try again.');
      }
    );
  }

  addDoctor(): void {
    const dialogRef = this.dialog.open(DoctorComponent, {
      width: '400px',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log('Doctor added successfully');
        this.loadDoctors();
      }
    });
  }

  editDoctor(doctor: any): void {
    const dialogRef = this.dialog.open(EditDoctorComponent, {
      width: '400px',
      data: doctor
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log('Doctor updated successfully');
        this.loadDoctors();
      }
    });
  }
  deleteDoctor(doctor: any): void {
    const dialogRef = this.dialog.open(DeleteDoctorComponent, {
      width: '400px',
      data: { doctor }, // Pass the doctor object to the dialog
    });
  
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'deleted') {
        alert('Doctor deleted successfully!');
        this.loadDoctors(); // Refresh the list after deletion
      } else if (result === 'error') {
        alert('Error deleting doctor. Please try again.');
      }
    });
  }
}  