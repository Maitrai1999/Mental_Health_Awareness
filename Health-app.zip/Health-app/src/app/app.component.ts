import { Component } from '@angular/core';
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AdminComponent } from './admin/admin.component';
import { DoctorComponent } from './doctor/doctor.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { HomeComponent } from './home/home.component';
import { MatSnackBar} from '@angular/material/snack-bar';
import { PatientDashboardComponent } from './patient-dashboard/patient-dashboard.component';
import { EditDoctorComponent } from './edit-doctor/edit-doctor.component';
import { DeleteDoctorComponent } from './delete-doctor/delete-doctor.component';
import { MatTableModule } from '@angular/material/table';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,RegisterComponent,LoginComponent, FormsModule, RouterLink,CommonModule,RouterModule,AdminComponent,DoctorComponent,AdminDashboardComponent,HomeComponent,PatientDashboardComponent,EditDoctorComponent,DeleteDoctorComponent,MatTableModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Health-app';
}
