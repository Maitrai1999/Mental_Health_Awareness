import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminLoginService {

  private loggedIn = false;

  validateLogin(username: string, password: string): Observable<boolean> {
    // Hardcoded admin credentials for demonstration
    const validUsername = 'admin';
    const validPassword = 'admin@123';

    if (username === validUsername && password === validPassword) {
      return of(true);
    }
    return of(false);
  }

   // Check if the admin is logged in
   isAdminLoggedIn(): boolean {
    return this.loggedIn;
  }

  // Optional: Logout the admin
  logout(): void {
    this.loggedIn = false;
  }
}
