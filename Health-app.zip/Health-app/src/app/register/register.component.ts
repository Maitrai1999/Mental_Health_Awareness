import { Component } from '@angular/core';
import { Router, RouterLink, RouterModule } from '@angular/router';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { RegisterService } from '../register.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register-unique',
  standalone:true,
  imports:[FormsModule,ReactiveFormsModule, CommonModule, RouterModule, RouterLink],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
 
    patient = {
      name: '',
      email: '',
      number: '',
      address: '',
      password: ''
    };
  
    isRegistered = false;
    errorMessage = ''; // To store error messages
  
    constructor(private registerService: RegisterService, private router: Router) {}
  
    onSubmit(registerForm: NgForm): void {
      // Check form validity
      if (!registerForm.valid) {
        this.errorMessage = 'Please fill out all fields correctly.';
        return;
      }
  
      // Call register service
      this.registerService.register(this.patient).subscribe(
        (response) => {
          console.log('Registration successful', response);
          this.isRegistered = true;
          this.errorMessage = ''; // Clear any previous error message
  
          // Redirect to login after a short delay
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        },
        (error) => {
          console.error('Registration failed', error);
          this.isRegistered = false;
  
          // Handle specific errors
          this.errorMessage = error.error?.message || 'Registration failed. Please try again.';
        }
      );
    }
  }
  