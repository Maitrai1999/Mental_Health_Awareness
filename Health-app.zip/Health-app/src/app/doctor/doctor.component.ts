import { ChangeDetectorRef, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterModule } from '@angular/router';
import { DoctorService } from '../doctor.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-doctor',
  standalone: true,
  imports: [
    CommonModule,ReactiveFormsModule,FormsModule,ReactiveFormsModule, RouterModule, RouterLink ],
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css'],
})
export class DoctorComponent {
      doctorForm: FormGroup;
    isSaveSuccessful: boolean | null = null; // Flag to track save status
    saveMessage: string = ''; // Message to display save status
  
    @Output() doctorAdded = new EventEmitter<void>(); // Notify parent to refresh the list
  
    constructor(
      private fb: FormBuilder,
      private doctorService: DoctorService,
      public dialogRef: MatDialogRef<DoctorComponent>,
      private cdr: ChangeDetectorRef
    ) {
      // Initialize the form with empty fields for a new doctor
      this.doctorForm = this.fb.group({
        name: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        contactNumber: ['', Validators.required],
        specialization: ['', Validators.required],
        availability: ['', Validators.required]
      });
    }
  
    // Method to handle form submission
    onSubmit(): void {
      if (this.doctorForm.valid) {
        const newDoctor = this.doctorForm.value;
  
        this.doctorService.addDoctor(newDoctor).subscribe(
          (response) => {
            console.log('Doctor added successfully:', response);
            this.isSaveSuccessful = true;
            
            this.saveMessage = 'Doctor added successfully!';
            this.doctorForm.reset();
            this.cdr.detectChanges();
            this.doctorAdded.emit();
            setTimeout(() => this.dialogRef.close(response), 3000);
          },
          (error) => {
            console.error('Error adding doctor:', error);
            this.isSaveSuccessful = false;
            this.saveMessage = 'Error adding doctor. Please try again.';
            this.cdr.detectChanges(); // Manually trigger change detection
          }
        );
      }
    }
  
    // Method to handle cancel action
    onCancel(): void {
      this.dialogRef.close(false); // Close dialog without saving
    }
  }
  