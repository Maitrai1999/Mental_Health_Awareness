import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
  export class LoginComponent {
    credentials = {
      email: '',
      password: ''
    };
  
    loginSuccessMessage: string | null = null;
    loginErrorMessage: string | null = null;
  
    constructor(private loginService: LoginService, private router: Router) {}
  
    onSubmit() {
      this.loginService.login(this.credentials).subscribe(
        (response: any) => {
          // On success, show a success message and navigate if needed
          this.loginSuccessMessage = response.message;
          this.loginErrorMessage = null;  // Clear any previous error
          setTimeout(() => {
            this.router.navigate(['/patient-dashboard']);  // Redirect to dashboard or home
          }, 2000);
        },
        (error: { error: { message: string; }; }) => {
          // On error, show the error message
          this.loginSuccessMessage = null;  // Clear any previous success message
          this.loginErrorMessage = error.error?.message || 'Invalid email or password';
        }
      );
    }
  
    navigateToRegister() {
      this.router.navigate(['/register']);
    }
  }