import { importProvidersFrom } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule, provideHttpClient, withFetch } from '@angular/common/http'; 
import { routes } from './app.routes';

export const appConfig = {
  providers: [
    importProvidersFrom(
      RouterModule.forRoot(routes),
      HttpClientModule 
    ),
    provideHttpClient(withFetch()) // No need to pass { withFetch: true } here, just use this method
  ]
};

